import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Platform } from 'react-native';
import axios from 'axios';
import styles from './style';

import InputCampo from '../../components/InputCampo';
import CardFruta from '../../components/CardFruta';

// Endereço que devolve TODAS as frutas de uma vez.
// Na web a API bloqueia (CORS), então o pedido passa por um "proxy".
// No celular vai direto.
const URL_API = 'https://www.fruityvice.com/api/fruit/all';
const PROXY_WEB = 'https://api.allorigins.win/raw?url=';

export default function Fruta() {
    const [frutas, setFrutas] = useState([]);  // todas as frutas que vieram da API
    const [busca, setBusca] = useState('');    // texto digitado no filtro
    const [erro, setErro] = useState('');      // mensagem de erro

    // IMPORTANTE: busca as frutas na API
    // o [] no final faz rodar só UMA vez, quando a tela abre
    useEffect(() => {
        let endereco = URL_API;
        if (Platform.OS === 'web') {
            endereco = PROXY_WEB + encodeURIComponent(endereco);
        }

        axios.get(endereco)
            .then(response => setFrutas(response.data)) // guarda a lista inteira
            .catch(error => {
                console.error(error);
                setErro('Não consegui carregar as frutas.');
            });
    }, []);

    // filtra a lista que já está na memória (não chama a API de novo)
    const frutasFiltradas = frutas.filter(f =>
        f.name.toLowerCase().includes(busca.trim().toLowerCase())
    );

    return (
        <ScrollView
            style={styles.fundo}
            contentContainerStyle={styles.container}
            keyboardShouldPersistTaps='handled'
        >
            <View style={styles.conteudo}>
                <Text style={styles.titulo}>Frutas</Text>

                <InputCampo
                    placeholder='Filtrar (ex: apple)'
                    keyboardType='default'
                    value={busca}
                    onChangeText={setBusca}
                />

                {/* só aparece se deu erro */}
                {erro ? <Text style={styles.erro}>{erro}</Text> : null}

                {/* um card para cada fruta; key ajuda o React a identificar cada item */}
                {frutasFiltradas.map(f => (
                    <CardFruta key={f.id} fruta={f} />
                ))}
            </View>
        </ScrollView>
    );
}
