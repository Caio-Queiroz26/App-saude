import React, { useState } from 'react';
import { View, Text, Image, ScrollView } from 'react-native';
import styles from './style';

import InputCampo from '../../components/InputCampo';
import Botao from '../../components/Botao';
import BotaoLink from '../../components/BotaoLink';

export default function Cadastro({ navigation }) {
    // cada campo da tela fica guardado em um estado
    const [nome, setNome] = useState('');
    const [email, setEmail] = useState('');
    const [senha, setSenha] = useState('');
    const [confirmar, setConfirmar] = useState('');
    const [erro, setErro] = useState(''); // mensagem de erro (vazia = sem erro)

    // IMPORTANTE: validação do cadastro
    function cadastrar() {
        if (nome.trim() === '' || email.trim() === '' || senha === '' || confirmar === '') {
            setErro('Preencha todos os campos.');
            return; // para aqui
        }

        // 2) as duas senhas precisam ser iguais
        if (senha !== confirmar) {
            setErro('As senhas não são iguais.');
            return; // para aqui
        }

        // deu certo: limpa o erro e volta para o login
        setErro('');
        navigation.navigate('Login');
    }

    return (
        <ScrollView
            style={styles.fundo}
            contentContainerStyle={styles.container}
            keyboardShouldPersistTaps='handled'
        >
            <View style={styles.card}>
                <Image source={require('../../../assets/logo.png')} style={styles.logo} />
                <Text style={styles.titulo}>Criar conta</Text>
                <Text style={styles.subtitulo}>Preencha os dados para se cadastrar</Text>

                <Text style={styles.rotulo}>Nome:</Text>
                <InputCampo
                    placeholder='Digite seu nome'
                    keyboardType='default'
                    value={nome}
                    onChangeText={setNome}
                />

                <Text style={styles.rotulo}>E-mail:</Text>
                <InputCampo
                    placeholder='Digite seu e-mail'
                    keyboardType='email-address'
                    value={email}
                    onChangeText={setEmail}
                />

                <Text style={styles.rotulo}>Senha:</Text>
                <InputCampo
                    placeholder='Digite sua senha'
                    keyboardType='default'
                    secureTextEntry
                    value={senha}
                    onChangeText={setSenha}
                />

                <Text style={styles.rotulo}>Confirmar senha:</Text>
                <InputCampo
                    placeholder='Repita sua senha'
                    keyboardType='default'
                    secureTextEntry
                    value={confirmar}
                    onChangeText={setConfirmar}
                />

                {erro ? <Text style={styles.erro}>{erro}</Text> : null}

                <Botao titulo='Cadastrar' onPress={cadastrar} />

                <BotaoLink
                    texto='Já tem conta?'
                    destaque='Entrar'
                    onPress={() => navigation.navigate('Login')}
                />
            </View>
        </ScrollView>
    );
}
