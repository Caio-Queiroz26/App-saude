import React, { useState } from 'react';
import { View, Text, Image, ScrollView } from 'react-native';
import styles from './style';

// componentes reaproveitados do projeto
import InputCampo from '../../components/InputCampo';
import Botao from '../../components/Botao';
import BotaoLink from '../../components/BotaoLink';

export default function Login({ navigation }) {
    // cada campo da tela fica guardado em um estado
    const [email, setEmail] = useState('');
    const [senha, setSenha] = useState('');
    const [erro, setErro] = useState(''); // mensagem de erro (vazia = sem erro)

    // IMPORTANTE: validação do login
    function entrar() {
        if (email.trim() === '' || senha === '') {
            setErro('Preencha o e-mail e a senha.');
            return; 
        }

        // deu certo: limpa o erro e vai para a Home
        // (replace = troca a tela, assim não dá para voltar ao login pelo botão voltar)
        setErro('');
        navigation.replace('Home');
    }

    return (
        <ScrollView
            style={styles.fundo}
            contentContainerStyle={styles.container}
            keyboardShouldPersistTaps='handled'
        >
            <View style={styles.card}>
                <Image source={require('../../../assets/logo.png')} style={styles.logo} />
                <Text style={styles.titulo}>Bem-vindo!</Text>
                <Text style={styles.subtitulo}>Entre para cuidar da sua saúde</Text>

                <Text style={styles.rotulo}>E-mail:</Text>
                <InputCampo
                    placeholder='Digite seu e-mail'
                    keyboardType='email-address'
                    value={email}
                    onChangeText={setEmail}
                />

                <Text style={styles.rotulo}>Senha:</Text>
                {/* secureTextEntry esconde a senha com bolinhas */}
                <InputCampo
                    placeholder='Digite sua senha'
                    keyboardType='default'
                    secureTextEntry
                    value={senha}
                    onChangeText={setSenha}
                />

                {/* só aparece se tiver erro */}
                {erro ? <Text style={styles.erro}>{erro}</Text> : null}

                <Botao titulo='Entrar' onPress={entrar} />

                {/* leva para a tela de cadastro */}
                <BotaoLink
                    texto='Não tem conta?'
                    destaque='Cadastre-se'
                    onPress={() => navigation.navigate('Cadastro')}
                />
            </View>
        </ScrollView>
    );
}
