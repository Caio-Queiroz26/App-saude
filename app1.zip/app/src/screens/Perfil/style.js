import { StyleSheet } from 'react-native';
import { colors, layout, radius, shadows, spacing } from '../../theme';

export default StyleSheet.create({
    fundo: {
        flex: 1,
        backgroundColor: colors.background,
    },
    container: {
        flexGrow: 1,
        padding: spacing.lg,
        justifyContent: 'center',
        alignItems: 'center',
    },
    card: {
        width: '100%',
        maxWidth: layout.maxFormWidth,
        backgroundColor: colors.surface,
        borderRadius: radius.xl,
        padding: spacing.lg,
        borderWidth: 1,
        borderColor: colors.border,
        ...shadows.card,
    },
    titulo: {
        fontSize: 26,
        fontWeight: '700',
        color: colors.text,
        textAlign: 'center',
        marginBottom: spacing.md,
    },
    // foto redonda
    foto: {
        width: 140,
        height: 140,
        borderRadius: 70,
        alignSelf: 'center',
        backgroundColor: colors.primarySoft,
        marginBottom: spacing.sm,
    },
    rotulo: {
        fontSize: 14,
        fontWeight: '600',
        color: colors.textMuted,
        marginTop: spacing.md,
        marginBottom: 6,
    },
    nome: {
        fontSize: 18,
        fontWeight: '600',
        color: colors.text,
        textAlign: 'center',
    },
});
