import React, { useState } from 'react';
import { View, Text, Image, ScrollView } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import styles from './style';

import InputCampo from '../../components/InputCampo';
import Botao from '../../components/Botao';

export default function Perfil() {
    const [nome, setNome] = useState('');   // nome do usuário
    const [foto, setFoto] = useState(null); // endereço da foto escolhida

    // IMPORTANTE: abre a galeria para escolher a foto de perfil
    async function escolherFoto() {
        const resultado = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ['images'],
            allowsEditing: true, // deixa cortar a foto
            aspect: [1, 1],      // foto quadrada
            quality: 0.7,
        });

        // se o usuário não cancelou, guarda a foto
        if (!resultado.canceled) {
            setFoto(resultado.assets[0].uri);
        }
    }

    return (
        <ScrollView
            style={styles.fundo}
            contentContainerStyle={styles.container}
            keyboardShouldPersistTaps='handled'
        >
            <View style={styles.card}>
                <Text style={styles.titulo}>Meu Perfil</Text>

                {/* se tiver foto mostra ela, senão mostra o avatar padrão */}
                <Image
                    source={foto ? { uri: foto } : require('../../../assets/avatar.png')}
                    style={styles.foto}
                />

                <Botao titulo='Escolher foto' onPress={escolherFoto} />

                <Text style={styles.rotulo}>Nome:</Text>
                <InputCampo
                    placeholder='Digite seu nome'
                    keyboardType='default'
                    value={nome}
                    onChangeText={setNome}
                />

                <Text style={styles.nome}>{nome ? 'Olá, ' + nome + '!' : ''}</Text>
            </View>
        </ScrollView>
    );
}
