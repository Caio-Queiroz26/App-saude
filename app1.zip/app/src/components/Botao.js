import React from 'react';
import { Pressable, Text, StyleSheet } from 'react-native';
import { colors, radius, spacing } from '../theme';

// Botão simples, igual ao botão "Calcular" da tela de IMC.
const Botao = ({ titulo, onPress }) => {
    return (
        <Pressable
            style={({ pressed }) => [styles.btn, pressed && styles.btnPressed]}
            onPress={onPress}
        >
            <Text style={styles.texto}>{titulo}</Text>
        </Pressable>
    );
};

export default Botao;

const styles = StyleSheet.create({
    btn: {
        width: '100%',
        height: 50,
        backgroundColor: colors.primary,
        borderRadius: radius.pill,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: spacing.sm,
    },
    btnPressed: {
        backgroundColor: colors.primaryDark,
    },
    texto: {
        color: colors.textOnPrimary,
        fontWeight: '600',
        fontSize: 16,
    },
});
