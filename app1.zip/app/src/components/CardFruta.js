import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, radius, spacing } from '../theme';

// Card que mostra os dados de uma fruta que veio da API.
// "fruta" é o objeto que a API devolve (nome, família, nutrições...).
const CardFruta = ({ fruta }) => {
    return (
        <View style={styles.card}>
            <Text style={styles.titulo}>{fruta.name}</Text>

            <Text style={styles.linha}>Família: <Text style={styles.valor}>{fruta.family}</Text></Text>
            <Text style={styles.linha}>Gênero: <Text style={styles.valor}>{fruta.genus}</Text></Text>
            <Text style={styles.linha}>Ordem: <Text style={styles.valor}>{fruta.order}</Text></Text>

            {/* nutrições (valores para 100 g da fruta) */}
            <Text style={styles.subtitulo}>Nutrição (100 g)</Text>
            <Text style={styles.linha}>Calorias: <Text style={styles.valor}>{fruta.nutritions.calories}</Text></Text>
            <Text style={styles.linha}>Carboidratos: <Text style={styles.valor}>{fruta.nutritions.carbohydrates} g</Text></Text>
            <Text style={styles.linha}>Proteínas: <Text style={styles.valor}>{fruta.nutritions.protein} g</Text></Text>
            <Text style={styles.linha}>Gorduras: <Text style={styles.valor}>{fruta.nutritions.fat} g</Text></Text>
            <Text style={styles.linha}>Açúcar: <Text style={styles.valor}>{fruta.nutritions.sugar} g</Text></Text>
        </View>
    );
};

export default CardFruta;

const styles = StyleSheet.create({
    card: {
        backgroundColor: colors.surface,
        borderWidth: 1,
        borderColor: colors.border,
        borderRadius: radius.md,
        padding: spacing.md,
        marginTop: spacing.md,
    },
    titulo: {
        fontSize: 22,
        fontWeight: '700',
        color: colors.text,
        marginBottom: spacing.sm,
    },
    subtitulo: {
        fontSize: 16,
        fontWeight: '700',
        color: colors.text,
        marginTop: spacing.md,
        marginBottom: 2,
    },
    linha: {
        fontSize: 14,
        color: colors.textMuted,
        marginTop: 4,
    },
    valor: {
        fontSize: 16,
        fontWeight: '600',
        color: colors.text,
    },
});
