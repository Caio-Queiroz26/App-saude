// App.js
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Home from './src/screens/Home';
import Imc from './src/screens/Imc';
import Agua from './src/screens/Agua';
import Alergia from './src/screens/Alergia';
import Dica from './src/screens/Dica';
import Emergencia from './src/screens/Emergencia';
import Fruta from './src/screens/Fruta';
import Glicemia from './src/screens/Glicemia';
import Pressao from './src/screens/Pressao';
import Meditacao from './src/screens/Meditacao';
import Remedio from './src/screens/Remedio';
import Sangue from './src/screens/Sangue';
import Perfil from './src/screens/Perfil';
import BotaoPerfil from './src/components/BotaoPerfil';
import Vacina from './src/screens/Vacina';
import Login from './src/screens/Login';
import Cadastro from './src/screens/Cadastro';

import { colors } from './src/theme';

const Stack = createNativeStackNavigator();

// Aparência padrão do cabeçalho, aplicada a todas as telas
const opcoesPadrao = {
  headerStyle: { backgroundColor: colors.header },
  headerTintColor: colors.headerText,
  headerTitleStyle: { fontWeight: '600' },
  headerShadowVisible: false,
  contentStyle: { backgroundColor: colors.background },
};

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName='Login'
        screenOptions={({ navigation }) => ({
          ...opcoesPadrao,
          // botão de perfil no canto superior direito de todas as telas
          headerRight: () => <BotaoPerfil onPress={() => navigation.navigate('Perfil')} />,
        })}
      >
        {/* login e cadastro: sem cabeçalho */}
        <Stack.Screen name='Login' component={Login} options={{ headerShown: false }} />
        <Stack.Screen name='Cadastro' component={Cadastro} options={{ headerShown: false }} />
        <Stack.Screen name='Home' component={Home} options={{ headerBackVisible: false }} />
        <Stack.Screen name='Imc' component={Imc} />
        <Stack.Screen name='Agua' component={Agua} />
        <Stack.Screen name='Sangue' component={Sangue} />
        <Stack.Screen name='Fruta' component={Fruta} />
        {/* na tela de perfil não precisa do botão de perfil */}
        <Stack.Screen name='Perfil' component={Perfil} options={{ headerRight: () => null }} />
      </Stack.Navigator>
      <StatusBar style='light' />
    </NavigationContainer>
  );
}
